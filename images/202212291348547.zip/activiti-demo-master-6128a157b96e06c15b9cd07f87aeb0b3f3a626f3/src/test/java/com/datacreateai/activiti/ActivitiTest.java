package com.datacreateai.activiti;

import org.activiti.engine.*;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.*;

/**
 * @program: activiti-demo
 * @description: 工作流测试类
 * @author: Anchor
 * @create: 2021-09-06
 **/
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ActivitiTest {
    //流程文件名称
    private final static String BPMN = "processes/myProcess.bpmn";
    //工作流引擎
    private static ProcessEngine processEngine = ProcessEngineConfiguration.createProcessEngineConfigurationFromResourceDefault().buildProcessEngine();
    //流程相关
    @Autowired
    private RuntimeService runtimeService;
    //任务相关
    @Autowired
    private TaskService taskService;
    //历史记录相关
    @Autowired
    private HistoryService historyService;

    /**
     * 流程部署
     * act_re_procdef
     */
    @Test
    public void deploy() {
        RepositoryService repositoryService = processEngine.getRepositoryService();//资源对象
        Deployment deployment = repositoryService.createDeployment()//创建一个部署对象
                .name("请假流程")
                .addClasspathResource(BPMN)
                .deploy();
        System.out.println("部署ID："+deployment.getId());
        System.out.println("部署名称："+deployment.getName());
    }

    /**
     * 启动流程实例分配任务给个人
     * act_ru_task
     */
    @Test
    public void start() {
        //脑补一下这个是从前台传过来的数据
        String userKey="陈际栋";
        //每一个流程有对应的一个key这个是某一个流程内固定的写在bpmn内的
        String processDefinitionKey ="myProcess";
        HashMap<String, Object> variables=new HashMap<>();
        //userKey在上文的流程变量中指定了
        variables.put("userKey", userKey);
        variables.put("day", 2);
        variables.put("users", "陈际栋");

        ProcessInstance instance = runtimeService
                .startProcessInstanceByKey(processDefinitionKey,variables);

        System.out.println("流程实例ID:"+instance.getId());
        System.out.println("流程定义ID:"+instance.getProcessDefinitionId());
    }

    /**
     * 查询当前人的个人任务
     * act_ru_identitylink
     */
    @Test
    public void findTask(){
        String assignee = "陈际栋";
        List<Task> list = taskService.createTaskQuery().taskAssignee(assignee).orderByTaskCreateTime().desc().list();
        if(list!=null && list.size()>0){
            for(Task task:list){
                System.out.println("任务ID:"+task.getId());
                System.out.println("任务名称:"+task.getName());
                System.out.println("任务的创建时间:"+task.getCreateTime());
                System.out.println("任务的办理人:"+task.getAssignee());
                System.out.println("流程实例ID："+task.getProcessInstanceId());
                System.out.println("执行对象ID:"+task.getExecutionId());
                System.out.println("流程定义ID:"+task.getProcessDefinitionId());
                System.out.println("getOwner:"+task.getOwner());
                System.out.println("getCategory:"+task.getCategory());
                System.out.println("getDescription:"+task.getDescription());
                System.out.println("getFormKey:"+task.getFormKey());
                Map<String, Object> map = task.getProcessVariables();
                for (Map.Entry<String, Object> m : map.entrySet()) {
                    System.out.println("key:" + m.getKey() + " value:" + m.getValue());
                }
                for (Map.Entry<String, Object> m : task.getTaskLocalVariables().entrySet()) {
                    System.out.println("key:" + m.getKey() + " value:" + m.getValue());
                }
            }
        }
    }

    /**
     * 提交任务
     */
    @Test
    public void completeTask(){
        //任务ID
        String taskId = "9d25b7f6-0f83-11ec-8c1c-acde48001122";
        HashMap<String, Object> variables=new HashMap<>();
        variables.put("days", 2);//userKey在上文的流程变量中指定了
        taskService.complete(taskId,variables);
        System.out.println("提交任务：任务ID："+taskId);
    }


    /**
     * 流程图
     */
    @Test
    public void genProcessDiagram(){
        // https://blog.csdn.net/qq_40109075/article/details/110939639
    }
}